(()=>{var e={};e.id=532,e.ids=[532],e.modules={846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1630:e=>{"use strict";e.exports=require("http")},1645:e=>{"use strict";e.exports=require("net")},1820:e=>{"use strict";e.exports=require("os")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3756:()=>{},3873:e=>{"use strict";e.exports=require("path")},4075:e=>{"use strict";e.exports=require("zlib")},4631:e=>{"use strict";e.exports=require("tls")},4735:e=>{"use strict";e.exports=require("events")},4870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},4985:e=>{"use strict";e.exports=require("dns")},5511:e=>{"use strict";e.exports=require("crypto")},5591:e=>{"use strict";e.exports=require("https")},7308:()=>{},7910:e=>{"use strict";e.exports=require("stream")},8354:e=>{"use strict";e.exports=require("util")},9021:e=>{"use strict";e.exports=require("fs")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},9423:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>d,serverHooks:()=>m,workAsyncStorage:()=>u,workUnitAsyncStorage:()=>c});var o={};r.r(o),r.d(o,{POST:()=>l});var s=r(5456),i=r(2597),a=r(4180),n=r(6745),p=r(2324);async function l(e){try{let t=await e.json();console.log("Live Demo form data:",t);let r=p.createTransport({service:"gmail",auth:{user:"anasnizamani54@gmail.com",pass:"mdsw rxaj essq zijz"}}),o={from:{name:"Schoolynx Demo Request",address:"anasnizamani54@gmail.com"},to:"anasnizamani54@gmail.com",replyTo:t.email,subject:"New Live Demo Request",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 8px;">
          <h2 style="color: #dc2626; border-bottom: 2px solid #dc2626; padding-bottom: 10px;">New Live Demo Request</h2>
          
          <h3 style="color: #374151; margin-top: 20px;">👤 Contact Person Details</h3>
          <p><strong>Full Name:</strong> ${t.fullName}</p>
          <p><strong>Role:</strong> ${t.role}</p>
          <p><strong>Phone Number:</strong> ${t.phoneNumber}</p>
          <p><strong>WhatsApp:</strong> ${t.whatsapp||"Not provided"}</p>
          <p><strong>Email:</strong> ${t.email}</p>

          <h3 style="color: #374151; margin-top: 20px;">🏫 School Information</h3>
          <p><strong>School Name:</strong> ${t.schoolName}</p>
          <p><strong>City/Location:</strong> ${t.location}</p>
          <p><strong>Total Students:</strong> ${t.totalStudents}</p>
          <p><strong>Total Staff:</strong> ${t.totalStaff}</p>

          <h3 style="color: #374151; margin-top: 20px;">✅ Interested In</h3>
          <ul style="list-style-type: none; padding-left: 0;">
            ${t.interests.map(e=>`<li>✓ ${e}</li>`).join("")}
            ${t.otherInterest?`<li>✓ Other: ${t.otherInterest}</li>`:""}
          </ul>

          <h3 style="color: #374151; margin-top: 20px;">📅 Preferred Contact Time</h3>
          <p><strong>Date:</strong> ${t.preferredDate}</p>
          <p><strong>Time:</strong> ${t.preferredTime}</p>

          ${t.additionalNotes?`
            <h3 style="color: #374151; margin-top: 20px;">💬 Additional Notes</h3>
            <p>${t.additionalNotes}</p>
          `:""}

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666;">
            <p>This email was sent from the Schoolynx Live Demo Request Form</p>
          </div>
        </div>
      `},s={from:{name:"Schoolynx Team",address:"anasnizamani54@gmail.com"},to:t.email,subject:"Thank you for requesting a Schoolynx Demo",html:`
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 8px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #dc2626; font-size: 24px; margin-bottom: 10px;">✅ Thank You!</h1>
            <p style="color: #374151; font-size: 16px; line-height: 1.6;">
              Your inquiry has been successfully submitted.<br>
              Our team at Schoolynx will contact you shortly to understand your school's needs and provide a customized demo and pricing plan.
            </p>
          </div>

          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0;">
              We look forward to helping you digitize and simplify your school management.
            </p>
          </div>

          <div style="margin-top: 30px; padding: 20px; background-color: #f3f4f6; border-radius: 8px;">
            <p style="color: #374151; margin: 0 0 10px 0;">
              <strong>📞 For urgent queries, feel free to contact us at:</strong><br>
              +92-XXX-XXXXXXX
            </p>
            <p style="color: #374151; margin: 0;">
              <strong>🌐 Visit us at:</strong><br>
              <a href="https://www.schoolynx.com" style="color: #dc2626; text-decoration: none;">www.schoolynx.com</a>
            </p>
          </div>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; font-size: 12px; color: #666; text-align: center;">
            <p>This is an automated message, please do not reply to this email.</p>
          </div>
        </div>
      `};return await r.sendMail(o),t.email&&await r.sendMail(s),n.NextResponse.json({success:!0,message:"Demo request submitted successfully"})}catch(t){let e=t instanceof Error?t.message:"Unknown error occurred";return console.error("Demo request submission failed:",e),n.NextResponse.json({success:!1,message:"Demo request submission failed",error:e},{status:500})}}let d=new s.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/live-demo/route",pathname:"/api/live-demo",filename:"route",bundlePath:"app/api/live-demo/route"},resolvedPagePath:"D:\\Git-Projects\\schoolnyx-core\\src\\app\\api\\live-demo\\route.ts",nextConfigOutput:"",userland:o}),{workAsyncStorage:u,workUnitAsyncStorage:c,serverHooks:m}=d;function x(){return(0,a.patchFetch)({workAsyncStorage:u,workUnitAsyncStorage:c})}},9551:e=>{"use strict";e.exports=require("url")},9646:e=>{"use strict";e.exports=require("child_process")}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[815,536,324],()=>r(9423));module.exports=o})();